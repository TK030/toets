<?php

$getal = 1;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 2;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 3;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 4;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 5;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 6;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 7;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 8;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 9;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 10;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 11;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}

$getal = 12;
for ($i = 1; $i <= 12; $i++) {
    $product = $i * $getal;
    echo "$getal * $i = $product" . PHP_EOL . PHP_EOL;
}
